package com.htsoft.converter;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;


public class ToNormal {
	public static void main(String args[]){
		String modelPath = args[0];
		listFiles(modelPath);
		System.out.println("Successfully change to normal.");
	}
	
	public static void listFiles(String path) {
		try {
			File file = new File(path);
			if (file.isFile()) {// 是否为文件
				System.out.println(file.getName() + "文件");
				System.out.println(file.canRead() ? "可读" : "不可读");
				System.out.println(file.canWrite() ? "可写" : "不可写");
				System.out.println(file.length() + "字节");
			} else {
				// 列出所有的文件及目录
				File[] files = file.listFiles();
				ArrayList<File> fileList = new ArrayList<File>();
				for (int i = 0; i < files.length; i++) {
					// 先列出目录
					if (files[i].isDirectory()) {// 是否为目录
						// 取得文件名
						// System.out.println("[" + files[i].getPath() + "]");
						listFiles(files[i].getPath());
					} else {
						// 文件先存入fileList,待会再列出
						if(files[i].getName().endsWith(".hbm.xml")){
							fileList.add(files[i]);
						}
						
					}
				}
				// 列出文件
				for (File f : fileList) {
					toNormal(f.getPath());
				}
			}

		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("using:java FileDemo pathname");
		}
	}

	public static void toNormal(String filePath) {
		Document doc = ConverterUtil.load(filePath);
		Element root = doc.getRootElement();
		
		Element generator = root.element("class").element("id").element("generator");
		generator.addAttribute("class", "native");
		Element param = generator.element("param");
		if(param != null){
			generator.remove(param);
		}
		
		ConverterUtil.docToXmlFile(doc,filePath);
		System.out.println(filePath);
	}
	
}
