package com.htsoft.converter;

import org.dom4j.Document;

public class Converter {
	private Document document;
	private String filePath;
	public Document getDocument() {
		return document;
	}
	public void setDocument(Document document) {
		this.document = document;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	
}
